window.onload = function() {

  // Retrieve the users name.
  var name = localStorage.getItem('Name'); 
		document.getElementById("current").innerHTML=name;
}

// Save this script as `options.js`

// Saves options to localStorage.
function save_options() {

if (document.getElementById("Name").value == "" && document.getElementById("Name").value == "")
{
     var status = document.getElementById("status");
  status.innerHTML = "<span style='color:red;'><B>Enter Channel Name!</B></span>";
  setTimeout(function() {
    status.innerHTML = "";
  }, 2050);
}
else
{
      var input = document.getElementById("Name");
	localStorage.setItem("Name", input.value);

  // Update status to let user know options were saved.
  var status = document.getElementById("status");
  status.innerHTML = "<span style='color:green;'><B>Saved.</B></span>";
  setTimeout(function() {
    status.innerHTML = "";
  }, 2050);
}

}

document.querySelector('#save').addEventListener('click', save_options);