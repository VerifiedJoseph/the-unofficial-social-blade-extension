window.onload = function() {



  // Retrieve the users name.
  var name = localStorage.getItem('Name'); 
		document.getElementById("iframe").innerHTML='<iframe id="fr" src="http://widget.socialblade.com/widget.php?u='+ name + '" style="overflow: hidden; height: 105px; width: 200px; border: 0;" scrolling="no" frameBorder="0"></iframe>';
};

 
        
                var fr = document.getElementById("fr")
                var anchors = fr.document.getElementsByTagName("a");
                for (var i in anchors) {
                    anchors[i].setAttribute("target", "_blank");
					}