$(document).ready(function () {
	//chrome.browserAction.setBadgeText({text:"Dev"});
	
	$('.options, #options-two').on("click", function() {
		if (chrome.runtime.openOptionsPage) {
			chrome.runtime.openOptionsPage();
		}
	});
	
	chrome.storage.sync.get({		
		// Use default values
		channel_one: '',
		channel_two: '',
	}, function(items) {
		
		if(items.channel1 == '') {
			if (localStorage.getItem("Name") != null) { // See if a localStorage item is set 
				var channel = localStorage.getItem("Name");
				
				chrome.storage.sync.set({ // Update chrome.storage with the localStorage item 
					channel_one: channel
				}, function() {
					console.log('added localStorage name to chrome sync storage');
				});
			}
		}
		
		console.log(items);
		
		if(items.channel_one == "" && items.channel_two == ""){
			$('.error').show();
			
		} else {
			var iframeShow = "";
			var iframeShowTwo = "";
			
			if(items.channel_one != "") {
				iframeShow = '<div id="iframe"><a class="iframe-title-a" target="_blank" href="http://socialblade.com/youtube/user/' + items.channel_one +'"/><div class="iframe-title"></div><div class="iframe-show"><iframe id="fr" src="http://widget.socialblade.com/widget.php?u=' + items.channel_one +'" style="overflow: hidden; height: 116px; width: 220px; border: 0;" scrolling="no" frameBorder="0"></iframe></div></a></div>';
				
			}
			
			if(items.channel_two != "") {
				iframeShowTwo = '<div id="iframe"><a class="iframe-title-a" target="_blank" href="http://socialblade.com/youtube/user/' + items.channel_two +'"/><div class="iframe-title"></div><div class="iframe-show"><iframe id="fr" src="http://widget.socialblade.com/widget.php?u=' + items.channel_two +'" style="overflow: hidden; height: 116px; width: 220px; border: 0;" scrolling="no" frameBorder="0"></iframe></div></a></div>';
			}
			
			//$('.iframe-title-a').attr('href', 'http://socialblade.com/youtube/user/' + items.channel);
			$('#iframe-wrap').html(iframeShow + iframeShowTwo);		
		}
	});
	

});